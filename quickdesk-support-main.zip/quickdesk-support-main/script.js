document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('ticket-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const title = document.getElementById('ticket-title').value;
            const description = document.getElementById('ticket-description').value;
            const newTicket = {
                title,
                description,
                status: 'open'
            };

            try {
                const response = await axios.post('http://localhost:3000/tickets', newTicket);
                console.log('Ticket submitted:', response.data);
                fetchAndDisplayTickets();
            } catch (error) {
                console.error('Error submitting ticket:', error);
            }
        });
    }
    fetchAndDisplayTickets();
});

async function fetchAndDisplayTickets() {
    try {
        const response = await axios.get('http://localhost:3000/tickets');
        const tickets = response.data;
        const container = document.getElementById('tickets-container');
        container.innerHTML = '';
        
        tickets.forEach(ticket => {
            const ticketElement = document.createElement('div');
            ticketElement.className = 'ticket';
            ticketElement.innerHTML = `
                <h4>${ticket.title}</h4>
                <p>${ticket.description}</p>
                <p>Status: <span class="status-${ticket.status}">${ticket.status}</span></p>
            `;
            container.appendChild(ticketElement);
        });
    } catch (error) {
        console.error('Error fetching tickets:', error);
    }
}