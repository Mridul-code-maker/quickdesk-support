document.addEventListener('DOMContentLoaded', () => {
    const ticketListContainer = document.getElementById('ticketList');

    function displayTickets() {
        const tickets = JSON.parse(localStorage.getItem('tickets')) || [];
        ticketListContainer.innerHTML = '';

        if (tickets.length === 0) {
            ticketListContainer.innerHTML = '<p class="no-tickets">No tickets have been submitted yet.</p>';
            return;
        }

        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Title</th>
                    <th>Issue Type</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${tickets.map(ticket => `
                    <tr data-id="${ticket.id}">
                        <td>${ticket.id}</td>
                        <td>${ticket.name}</td>
                        <td>${ticket.email}</td>
                        <td>${ticket.title}</td>
                        <td>${ticket.issueType}</td>
                        <td>
                            <select class="status-select">
                                <option value="New" ${ticket.status === 'New' ? 'selected' : ''}>New</option>
                                <option value="In Progress" ${ticket.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                                <option value="Closed" ${ticket.status === 'Closed' ? 'selected' : ''}>Closed</option>
                            </select>
                        </td>
                        <td>
                            <button class="delete-btn">Delete</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        `;
        ticketListContainer.appendChild(table);

        // Add event listeners for status change and delete buttons
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const ticketId = e.target.closest('tr').dataset.id;
                const newStatus = e.target.value;
                updateTicketStatus(ticketId, newStatus);
            });
        });

        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const ticketId = e.target.closest('tr').dataset.id;
                deleteTicket(ticketId);
            });
        });
    }

    function updateTicketStatus(id, newStatus) {
        let tickets = JSON.parse(localStorage.getItem('tickets')) || [];
        tickets = tickets.map(ticket => {
            if (ticket.id == id) {
                ticket.status = newStatus;
            }
            return ticket;
        });
        localStorage.setItem('tickets', JSON.stringify(tickets));
        displayTickets();
    }

    function deleteTicket(id) {
        if (confirm('Are you sure you want to delete this ticket?')) {
            let tickets = JSON.parse(localStorage.getItem('tickets')) || [];
            tickets = tickets.filter(ticket => ticket.id != id);
            localStorage.setItem('tickets', JSON.stringify(tickets));
            displayTickets();
        }
    }

    displayTickets();
});