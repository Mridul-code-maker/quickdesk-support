# QuickDesk: A Simple Support Ticket System

## Project Description
QuickDesk is a simple, browser-based support ticket management system. It allows users to submit support tickets and provides a separate admin dashboard to view and manage those tickets. This project was built for the ODOO HACKATHON to demonstrate a basic, functional web application.

## Features
- *User Submission Form:* Users can submit tickets with their name, email, a title, and an issue type.
- *Admin Dashboard:* A dashboard where an admin can view a list of all submitted tickets.
- *Ticket Management:* Admins can change the status of tickets (New, In Progress, Closed) and delete tickets from the list.
- *Browser-based Storage:* All ticket data is stored locally in the browser using localStorage, meaning no backend or database is required.

## How to Run
1. Clone this repository to your local machine.
2. Open the index.html file in your web browser to access the user submission form.
3. Open the admin.html file in your web browser to access the admin dashboard.
4. (Optional) Submit a few test tickets from the index.html page to see them appear in the admin.html dashboard.

## Technologies Used
- HTML5
- CSS3
- JavaScript (with localStorage)
